# 📜 Steve Jobs Tribute Page
**Project within:** Responsive Web Design Certification by Free Code Camp <a href="https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-product-landing-page/">View Certification</a>


**Objective:** Build a Tribute Page

**Requirements:** <a href="https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-tribute-page/">View Requirements</a>

**Solution Link:** <a href="https://cosminmoldovan.github.io/fcc-tribute-page/">Live Demo</a>

<img src="project-thumbnail.png" />