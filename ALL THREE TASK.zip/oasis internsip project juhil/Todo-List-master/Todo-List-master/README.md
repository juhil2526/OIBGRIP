# Todo-List

Multiple purpose To do list created using Jquery, font awesome and google fonts.

## Codepen: https://codepen.io/Akkijay/full/LdKeeg/
